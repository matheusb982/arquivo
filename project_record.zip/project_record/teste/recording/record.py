import requests
import time
from recording import run_record

class record(object):
    def run(self):

        hoje = "%s" % (time.strftime("%Y_%m_%d"))
        arquivof = open("log_record.%s.log" % (hoje), "a")
        hora = time.strftime("%H:%M:%S %Z")

        arquivof.write("[%s] Iniciando Processo.\r\n" % (hora))

        zero_dev = [0, 0, 0, 0, 0, 0, 0, 0]
        zero_ape = [0, 0, 0, 0, 0, 0, 0, 0]
        zero_apk = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]

        dev  = record.convert_values(self, '0004a30c781c29bb')

        r = run_record.running()

        result_dev = r.run('DevEUI', 'READ', dev)
        result_ape = r.run('AppEUI', 'READ', dev)
        result_apk = r.run('AppKEY', 'READ', dev)

        if (result_dev == zero_dev) and (result_ape == zero_ape) and ( result_apk == zero_apk):
            #Iniciar gravação de etiqueta
            print('------Iniciar gravação de etiqueta------')
            arquivof.write("[%s] ------Iniciar gravação de ETIQUETA------\r\n" % (hora))

            url = 'http://54.207.55.58:3000/api/v1/tags.json'
            headers = {'X-User-Email':'matheusb982@gmail.com', 'X-User-Token':'-uTbeyph7H1cXserAPYW'}

            r = requests.get(url, headers=headers)

            js = r.json()

            if (r.status_code == 200):
                print (js[0]['id'])
                print (js[0]['deveui'])
                print (js[0]['appeui'])
                print (js[0]['appkey'])

                arquivof.write("[%s] Dados da API | ID: %s | DevEUI: %s | AppEUI: %s | AppKEY: %s |.\r\n" % (hora, js[0]['id'], js[0]['deveui'], js[0]['appeui'], js[0]['appkey']))

                rr = run_record.running()

                dev_et = record.convert_values(self, js[0]['deveui'])
                appe_et = record.convert_values(self, js[0]['appeui'])
                appk_et = record.convert_values(self, js[0]['appkey'])

                result_dev = rr.run('DevEUI', 'WRITE', dev_et)
                result_appe = rr.run('AppEUI', 'WRITE', appe_et)
                result_appk = rr.run('AppKEY', 'WRITE', appk_et)

                print('RETORNO DA GRAVAÇÃO')
                param_dev = 0
                if (result_dev == [0, 0]) or (record.verif_payload(self, result_dev) == [0, 0]):
                    #print('sucesso dev')
                    param_dev = 1

                param_appe = 0
                if (result_appe == [0, 0]) or (record.verif_payload(self, result_appe) == [0, 0]):
                    #print('sucesso appe')
                    param_appe = 1

                param_appk = 0
                if (result_appk == [0, 0]) or (record.verif_payload(self, result_appk) == [0, 0]):
                    #print('sucesso appk')
                    param_appk = 1

                #print('GRAVADO')


                # update api
                # dat = {'tag[used]':'true'}
                #
                # urlp = 'http://54.207.55.58:3000/api/v1/tags/'+str(js[0]['id'])
                #
                # rp = requests.put(urlp, headers=headers, data = dat)
                #
                # print(rp.text)

                if (param_dev == 1) and (param_appe == 1) and (param_appk == 1):
                    arquivof.write("[%s] Etiqueta gravado com sucesso!\r\n" % (hora))
                    arquivof.close()
                    return [2, 'Etiqueta gravado com sucesso!']
                else:
                    arquivof.write("[%s] Erro ao gravar etiqueta!\r\n" % (hora))
                    arquivof.close()
                    result_dev = rr.run('DevEUI', 'WRITE', zero_dev)
                    result_appe = rr.run('AppEUI', 'WRITE', zero_ape)
                    result_appk = rr.run('AppKEY', 'WRITE', zero_apk)
                    return [0, 'Erro ao gravar etiqueta']

            else:
                arquivof.write("[%s] Erro ao se comunicar com AP!\r\n" % (hora))
                arquivof.close()
                return [0, 'Erro ao se comunicar com API']


        elif (result_dev != zero_dev) and (result_ape == zero_ape) and ( result_apk == zero_apk):
            #Iniciar gravação de modem
            print('------Iniciar gravação do modem------')
            arquivof.write("[%s] ------Iniciar gravação do MODEM------\r\n" % (hora))
            url = 'http://54.207.55.58:3000/api/v1/modems.json'
            headers = {'X-User-Email':'matheusb982@gmail.com', 'X-User-Token':'-uTbeyph7H1cXserAPYW'}

            r = requests.get(url, headers=headers)

            js = r.json()

            if (r.status_code == 200):
                print (js[0]['id'])
                print (js[0]['appeui'])
                print (js[0]['appkey'])

                arquivof.write("[%s] Dados da API | ID: %s | AppEUI: %s | AppKEY: %s |.\r\n" % (hora, js[0]['id'], js[0]['appeui'], js[0]['appkey']))

                rr = run_record.running()

                result_devm = rr.run('DevEUI', 'READ', dev)

                dev_m = record.convert_dec(self, result_devm)

                appe_mod = record.convert_values(self, js[0]['appeui'])
                appk_mod = record.convert_values(self, js[0]['appkey'])

                result_appe = rr.run('AppEUI', 'WRITE', appe_mod)
                result_appk = rr.run('AppKEY', 'WRITE', appk_mod)

                param_appe = 0
                if (result_appe == [0, 0]) or (record.verif_payload(self, result_appe) == [0, 0]):
                    #print('sucesso appe')
                    param_appe = 1

                param_appk = 0
                if (result_appk == [0, 0]) or (record.verif_payload(self, result_appk) == [0, 0]):
                    #print('sucesso appk')
                    param_appk = 1

                # update api
                # dat = {'modem[used]':'true', 'modem[deveui]':dev_m}
                #
                # urlp = 'http://54.207.55.58:3000/api/v1/modems/'+str(js[0]['id'])
                #
                # rp = requests.put(urlp, headers=headers, data = dat)
                #
                # print(rp.text)

                if (param_appe == 1) and (param_appk == 1):
                    arquivof.write("[%s] Modem gravado com sucesso!\r\n" % (hora))
                    arquivof.close()
                    return [2, 'Modem gravado com sucesso!']
                else:
                    arquivof.write("[%s] Erro ao gravar modem!\r\n" % (hora))
                    arquivof.close()
                    result_appe = rr.run('AppEUI', 'WRITE', zero_ape)
                    result_appk = rr.run('AppKEY', 'WRITE', zero_apk)
                    return [0, 'Erro ao gravar modem']

            else:
                arquivof.write("[%s] Erro ao se comunicar com AP!\r\n" % (hora))
                arquivof.close()
                return [0, 'Erro ao se comunicar com API']


        elif(result_dev == 9):
            return [0, 'ERRO: Verifique se há algum dispositivo conectado na porta!']
        elif (result_dev != zero_dev) and (result_ape != zero_ape) and ( result_apk != zero_apk):
            arquivof.write("[%s] Dispositivo já gravado!\r\n" % (hora))
            arquivof.close()
            return [1, 'Dispositivo já gravado']


    def convert_dec(self, deveuiq):
        value = deveuiq
        result = ''

        for x in value:
            if (len(str(hex(x).split('x')[-1])) == 1):
                res = '0'+hex(x).split('x')[-1]
            else:
                res = hex(x).split('x')[-1]

            result = result+res

        return result

    def convert_values(self, deveui):
        value = deveui

        temp = []
        for data in value:
           temp.append(int(data,16))

        result = []
        for (data1,data2) in zip(temp[1:len(temp):2],temp[0:len(temp):2]):
           result.append(data1+16*data2)

        return result

    def verif_payload(self, pay):
        ret = []

        ret.append(pay[-2])
        ret.append(pay[-3])

        hoje = "%s" % (time.strftime("%Y_%m_%d"))
        arquivog = open("log_record.%s.log" % (hoje), "a")
        hora = time.strftime("%H:%M:%S %Z")
        arquivog.write("[%s] Segunda verificação!\r\n" % (hora))
        arquivog.close()

        return ret
