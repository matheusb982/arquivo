import requests
from recording import run_record

class record(object):
    def run(self):
        url = 'http://54.207.55.58:3000/api/v1/tags.json'
        headers = {'X-User-Email':'matheus@example.com', 'X-User-Token':'NXycdFeCNpGy7s41j-XA'}

        r = requests.get(url, headers=headers)

        js = r.json()

        zero_dev = [0, 0, 0, 0, 0, 0, 0, 0]
        zero_ape = [0, 0, 0, 0, 0, 0, 0, 0]
        zero_apk = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]

        dev1  = '0004a30c781c29bb'
        ape1  = '70b3d57ef00064ea'
        apk1  = '0d0339f69c6949bec3529f7c163020d4'

        dev  = record.convert_values(self, dev1)
        ape  = record.convert_values(self, ape1)
        apk  = record.convert_values(self, apk1)

        r = run_record.running()

        result_dev = r.run('DevEUI', 'WRITE', zero_dev)
        result_appe = r.run('AppEUI', 'WRITE', zero_ape)
        #print('GRAVANDO APPKEY')
        result_appk = r.run('AppKEY', 'WRITE', zero_apk)
        #print('GRAVANDO APPKEY')
        # print('wswwwss')
        # print(result_appk)

        result_dev = r.run('DevEUI', 'READ', dev)
        result_ape = r.run('AppEUI', 'READ', dev)
        result_apk = r.run('AppKEY', 'READ', dev)

        # result_dev = r.run('DevEUI', 'WRITE', zero_dev)
        # result_appe = r.run('AppEUI', 'WRITE', zero_ape)
        # result_appk = r.run('AppKEY', 'WRITE', zero_apk)

        #print('**********')
        #print(dev)
        print('**********')
        print(result_dev)
        print(result_ape)
        print(result_apk)

        return 0

        #if r.status_code == 200:
            # print (js[0]['id'])
            # print (js[0]['deveui'])
            # print (js[0]['appeui'])
            # print (js[0]['appkey'])
            # zero_dev = [0, 0, 0, 0, 0, 0, 0, 0]
            # zero_ape = [0, 0, 0, 0, 0, 0, 0, 0]
            # zero_apk = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
            #
            # dev = record.convert_values(self, js[0]['deveui'])
            # appe = record.convert_values(self, js[0]['appeui'])
            # appk = record.convert_values(self, js[0]['appkey'])
            #
            # r = run_record.running()
            #
            # result_dev = r.run('DevEUI', 'READ', dev)
            # result_ape = r.run('AppEUI', 'READ', dev)
            # result_apk = r.run('AppKEY', 'READ', dev)
            #
            # print('**********')
            # print(result_dev)
            # print(result_ape)
            # print(result_apk)

            #if (result_dev == zero_dev) and (result_ape == zero_ape) and ( result_apk == zero_apk):
                # result_dev = r.run('DevEUI', 'WRITE', dev)
                # result_appe = r.run('AppEUI', 'WRITE', appe)
                # result_appk = r.run('AppKEY', 'WRITE', appk)
                #
                # param = 0
                # if (result_dev == [0, 0]):
                #     param +=1
                # else:
                #     print('Erro ao gravar DevEUI')
                #
                # if (result_appe == [0, 0]):
                #     param +=1
                # else:
                #     print('Erro ao gravar AppEUI')
                #
                # if (result_appk == [0, 0]):
                #     param +=1
                # else:
                #     print('Erro ao gravar AppKEY')
                #
                # if (param < 3):
                #     result_dev = r.run('DevEUI', 'WRITE', zero_dev)
                #     result_appe = r.run('AppEUI', 'WRITE', zero_ape)
                #     result_appk = r.run('AppKEY', 'WRITE', zero_apk)

            #    return param
            #else:
                # print('Verificando')
                #
                # url = 'http://54.207.55.58:3000/api/v1/tag_useds.json'
                # headers = {'X-User-Email':'matheus@example.com', 'X-User-Token':'NXycdFeCNpGy7s41j-XA'}
                #
                # r = requests.get(url, headers=headers)
                # js = r.json()
                #
                # i = 0
                # ver_rec = 0
                #
                # while(i < len(js)):
                #     dev_r = record.convert_values(self, js[i]['deveui'])
                #     appe_r = record.convert_values(self, js[i]['appeui'])
                #     appk_r = record.convert_values(self, js[i]['appkey'])
                #     if (result_dev == dev_r) and (result_ape == appe_r) and (result_apk == appk_r):
                #         ver_rec = 1
                #         break
                #     i += 1

                # if (ver_rec == 1):
                #     return 5
                # else:
                #     return 4

            # dat = {'tag[used]':'true'}
            #
            # urlp = 'http://54.207.55.58:3000/api/v1/tags/'+str(js[0]['id'])
            #
            # rp = requests.put(urlp, headers=headers, data = dat)
            #
            # print(rp.text)

        #else:
            # print ('Erro ao acessar API')
            # print (js['error'])
            #return 0

    def convert_values(self, deveui):
        value = deveui

        temp = []
        for data in value:
           temp.append(int(data,16))

        result = []
        for (data1,data2) in zip(temp[1:len(temp):2],temp[0:len(temp):2]):
           result.append(data1+16*data2)

        return result
