import tkinter as tk
from tkinter import *
from tkinter import messagebox
from recording import record
from recording import record_test

class Application(tk.Frame):
    def __init__(self, master=None):
        super().__init__(master)
        self.pack()
        self.create_widgets()

    def create_widgets(self):
        #button inital
        w = Label(self, text="")
        w.pack()
        self.hi_there = tk.Button(self, width=18, height=5)
        self.hi_there["text"] = "Iniciar"
        self.hi_there["command"] = self.say_hi
        self.hi_there.pack(side="top")


        #button quit
        # self.quit = tk.Button(self, text="QUIT", fg="red",
        #                       command=root.destroy)
        # self.quit.pack(side="bottom")

    def say_hi(self):
        print("Iniciando APP TEST...")
        r = record_test.record()
        result = r.run()

        # if result==3:
        messagebox.showinfo("Finalizado" , "sucesso")
        print('*****')
        print(result)
        # elif result==5:
        #     messagebox.showwarning("Warning","Placa já gravada")
        # elif result==4:
        #     messagebox.showwarning("Warning","Placa já gravada (Sem registro em banco)")
        # else:
        #     messagebox.showerror("Erro", "Erro ao fazer a gravação, verifique o LOG!")
        # self.action_recording('Hello')
        # messagebox.showerror("Error", "Error message")
        # messagebox.showwarning("Warning","Warning message")

    # def action_recording(self,text):
    #     print(text)

root = tk.Tk()
root.title("Gravação")
root.geometry("300x200")
app = Application(master=root)
app.mainloop()
