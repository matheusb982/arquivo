import requests
import time
from recording import run_record

class record(object):
    def run(self):

        hoje = "%s" % (time.strftime("%Y_%m_%d"))
        arquivof = open("log_record.%s.log" % (hoje), "a")
        hora = time.strftime("%H:%M:%S %Z")

        arquivof.write("[%s] Iniciando Regravação.\r\n" % (hora))

        zero_dev = [0, 0, 0, 0, 0, 0, 0, 0]
        zero_ape = [0, 0, 0, 0, 0, 0, 0, 0]
        zero_apk = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]

        dev  = record.convert_values(self, '0004a30c781c29bb')

        r = run_record.running()

        result_dev = r.run('DevEUI', 'READ', dev)
        result_ape = r.run('AppEUI', 'READ', dev)
        result_apk = r.run('AppKEY', 'READ', dev)

        dev_m = record.convert_dec(self, result_dev)

        url = 'http://54.207.55.58:3000/api/v1/modems/show_dev/'+dev_m
        headers = {'X-User-Email':'matheusb982@gmail.com', 'X-User-Token':'-uTbeyph7H1cXserAPYW'}

        r = requests.get(url, headers=headers)

        if (r.status_code == 200):
            js = r.json()

            if js != None:
                print('modem')
                r = run_record.running()

                appeui  = record.convert_values(self, js['appeui'])
                appkey  = record.convert_values(self, js['appkey'])

                result_appe = r.run('AppEUI', 'WRITE', appeui)
                result_appk = r.run('AppKEY', 'WRITE', appkey)

                param_appe = 0
                if (result_appe == [0, 0]) or (record.verif_payload(self, result_appe) == [0, 0]):
                    #print('sucesso appe')
                    param_appe = 1

                param_appk = 0
                if (result_appk == [0, 0]) or (record.verif_payload(self, result_appk) == [0, 0]):
                    #print('sucesso appk')
                    param_appk = 1


                if ((param_appe == 1) and (param_appk == 1)):
                    return [2, 'Modem gravado com sucesso!']
                else:
                    return [0, 'Erro ao gravar modem']

            else:
                url = 'http://54.207.55.58:3000/api/v1/tags/show_etq/'+dev_m
                headers = {'X-User-Email':'matheusb982@gmail.com', 'X-User-Token':'-uTbeyph7H1cXserAPYW'}

                r = requests.get(url, headers=headers)

                jso = r.json()

                if jso != None:
                    print('etiqueta')

                    appeui  = record.convert_values(self, jso['appeui'])
                    appkey  = record.convert_values(self, jso['appkey'])

                    print(appeui)
                    print(appkey)

                    # result_appe = r.run('AppEUI', 'WRITE', appeui)
                    # result_appk = r.run('AppKEY', 'WRITE', appkey)
                    #
                    # param_appe = 0
                    # if (result_appe == [0, 0]) or (record.verif_payload(self, result_appe) == [0, 0]):
                    #     #print('sucesso appe')
                    #     param_appe = 1
                    #
                    # param_appk = 0
                    # if (result_appk == [0, 0]) or (record.verif_payload(self, result_appk) == [0, 0]):
                    #     #print('sucesso appk')
                    #     param_appk = 1
                    #
                    #
                    # if ((param_appe == 1) and (param_appk == 1)):
                    #     return [2, 'Etiqueta gravado com sucesso!']
                    # else:
                    return [0, 'Erro ao gravar etiqueta']

        else:
            return [0, 'Erro ao se comunicar com API']


    def convert_dec(self, deveuiq):
        value = deveuiq
        result = ''

        for x in value:
            if (len(str(hex(x).split('x')[-1])) == 1):
                res = '0'+hex(x).split('x')[-1]
            else:
                res = hex(x).split('x')[-1]

            result = result+res

        return result

    def convert_values(self, deveui):
        value = deveui

        temp = []
        for data in value:
           temp.append(int(data,16))

        result = []
        for (data1,data2) in zip(temp[1:len(temp):2],temp[0:len(temp):2]):
           result.append(data1+16*data2)

        return result

    def verif_payload(self, pay):
        ret = []

        ret.append(pay[-2])
        ret.append(pay[-3])

        hoje = "%s" % (time.strftime("%Y_%m_%d"))
        arquivog = open("log_record.%s.log" % (hoje), "a")
        hora = time.strftime("%H:%M:%S %Z")
        arquivog.write("[%s] Segunda verificação!\r\n" % (hora))
        arquivog.close()

        return ret
