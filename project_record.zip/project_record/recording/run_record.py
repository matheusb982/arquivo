import serial
import time

class running(object):
    def run(self, option_name, option_action, option_value):
        ret_s = []
        print('------LOG RUNNING-------')
        try:
            print(option_value)
            ser = serial.Serial('/dev/ttyUSB0',9600,timeout = 0.250)
            ser.close()
            #%%
            START_BYTE, STOP_BYTE = 0xBB, 0xBB
            REQU_TYPE = {'WRITE':0x00,'READ':0x01,'ACKNOLEDGE_FRAME':0x02}
            DATA_TYPE = {'DevEUI':{'DATA':0x12,'PCT_LEN':{'READ':5,'WRITE':13},'PLD_LEN':8},
                         'AppEUI':{'DATA':0x13,'PCT_LEN':{'READ':5,'WRITE':13},'PLD_LEN':8},
                         'AppKEY':{'DATA':0x14,'PCT_LEN':{'READ':5,'WRITE':21},'PLD_LEN':16},
                         'AppsKEY':{'DATA':0x15,'PCT_LEN':{'READ':5,'WRITE':21},'PLD_LEN':16},
                         'NwsKEY':{'DATA':0x16,'PCT_LEN':{'READ':5,'WRITE':21},'PLD_LEN':16},
                         'DevADD':{'DATA':0x17,'PCT_LEN':{'READ':5,'WRITE':13},'PLD_LEN':8},
                         'ACK':{'DATA':0x18,'PCT_LEN':7,'PLD_LEN':2}}
        except serial.SerialException:
            return 9
            print("ERRO: Verifique se ha algum dispositivo conectado na porta!")
        #%%
        def PacketBuilder(start_byte,pct_len,req_type,data_type,payload,stop_byte):
            print('Building packet')
            if(req_type == REQU_TYPE['READ']):
                type_str = 'READ'
                packet = [start_byte,pct_len,req_type,data_type,stop_byte]
            if(req_type == REQU_TYPE['WRITE']):
                type_str = 'WRITE'
                packet = [start_byte,pct_len,req_type,data_type]
                if type(payload) != int:
                    for data in payload:
                        packet.append(data)
                else:
                    packet.append(payload)
                packet.append(stop_byte)

                if(data_type == DATA_TYPE['DevEUI']['DATA']):
                    print('DeviceEUI '+type_str+' request packet built')
                if(data_type == DATA_TYPE['AppEUI']['DATA']):
                    print('ApplicationEUI '+type_str+' request packet built')
                if(data_type == DATA_TYPE['AppKEY']['DATA']):
                    print('ApplicationKEY '+type_str+' request packet built')

            return packet

        def PopulatePayload(request,size):
            if(request == 'READ'):
                return

            if(request == 'WRITE'):
                nullPayload = option_value
                # for k in range(0,size):
                #     nullPayload.append(0)
            #nullPayload = option_value
            return nullPayload

        def FindByte(packet,byte):
            for k in range(len(packet)):
                if(packet[k] == byte):
                    return k

        def ReceivedPacketCleaner(packet,length):
            start = FindByte(packet[:],START_BYTE)
            stop  = FindByte(packet[::-1],STOP_BYTE)
            temp = PACK[start:len(PACK)-stop]
            if(stop == start + length):
                print('Packet cleaned sucessfully.')
                return temp
            else:
                print('Packet cleaning error')
                return temp

        def PacketReceivedCheck(packet):
            print('Checking received packet for frame errors')

            error = 0

            if(packet[0] != START_BYTE):
                print('Error: wrong Start Byte')
                hoje = "%s" % (time.strftime("%Y_%m_%d"))
                arquivo = open("log_record.%s.log" % (hoje), "a")
                hora = time.strftime("%H:%M:%S %Z")

                arquivo.write("[%s] Error: wrong Start Byte.\r\n" % (hora))
                arquivo.close()
                error = error | 0x01

            if(packet[1] != len(packet)):
                print('Error: wrong frame length')
                hoje = "%s" % (time.strftime("%Y_%m_%d"))
                arquivo = open("log_record.%s.log" % (hoje), "a")
                hora = time.strftime("%H:%M:%S %Z")

                arquivo.write("[%s] Error: wrong frame length.\r\n" % (hora))
                arquivo.close()
                error = error | 0x02

            if((packet[2] != REQU_TYPE['WRITE']) &
               (packet[2] != REQU_TYPE['ACKNOLEDGE_FRAME'])):
                print('Error: unknown request type')
                hoje = "%s" % (time.strftime("%Y_%m_%d"))
                arquivo = open("log_record.%s.log" % (hoje), "a")
                hora = time.strftime("%H:%M:%S %Z")

                arquivo.write("[%s] Error: unknown request type.\r\n" % (hora))
                arquivo.close()
                error = error | 0x04

            if((packet[3] != DATA_TYPE['DevEUI']['DATA']) &
               (packet[3] != DATA_TYPE['AppEUI']['DATA']) &
               (packet[3] != DATA_TYPE['AppKEY']['DATA']) &
               (packet[3] != DATA_TYPE['ACK']['DATA'])):
                print('Error: unknown data type received')

                hoje = "%s" % (time.strftime("%Y_%m_%d"))
                arquivo = open("log_record.%s.log" % (hoje), "a")
                hora = time.strftime("%H:%M:%S %Z")

                arquivo.write("[%s] Error: unknown data type received.\r\n" % (hora))
                arquivo.close()
                error = error | 0x08

            if(packet[-1] != STOP_BYTE):
                print('Error: wrong Stop Byte')

                hoje = "%s" % (time.strftime("%Y_%m_%d"))
                arquivo = open("log_record.%s.log" % (hoje), "a")
                hora = time.strftime("%H:%M:%S %Z")

                arquivo.write("[%s] Error: wrong Stop Byte.\r\n" % (hora))
                arquivo.close()
                error = error | 0x10

            if(error == 0):
                print('Packet checked: no frame errors')

            return error

        def PacketPayloadDecode(packet):
            print('Extracting packet payload')
            payload = 0
            if(packet[2] == REQU_TYPE['WRITE']):
                if((packet[3] == DATA_TYPE['DevEUI']['DATA'])):
                    payload = packet[4:-1]
                    print('DeviceEUI: '+str(payload))
                if(packet[3] == DATA_TYPE['AppEUI']['DATA']):
                    payload = packet[4:-1]
                    print('ApplicationEUI: '+str(payload))
                if(packet[3] == DATA_TYPE['AppKEY']['DATA']):
                    payload = packet[4:-1]
                    print('ApplicationKEY: '+str(payload))
            if(packet[2] == REQU_TYPE['ACKNOLEDGE_FRAME']):
                payload = packet[4:-1]
                print('Acknoledge packet: '+str(payload))

            return payload

        def AcknoledgeDecoder(ack):
            print('Decoding Acknoledge payload')

            if(ack[0] == 0):
                print('Process finished with no errors')

            if(ack[0] == 1):
                print('Process stage error: packet checking')
                hoje = "%s" % (time.strftime("%Y_%m_%d"))
                arquivo1 = open("log_record.%s.log" % (hoje), "a")
                hora = time.strftime("%H:%M:%S %Z")

                arquivo1.write("[%s] Process stage error: packet checking\r\n" % (hora))
                arquivo1.close()

            if(ack[0] == 2):
                print('Process stage error: packet decode')
                hoje = "%s" % (time.strftime("%Y_%m_%d"))
                arquivo1 = open("log_record.%s.log" % (hoje), "a")
                hora = time.strftime("%H:%M:%S %Z")

                arquivo1.write("[%s] Process stage error: packet decode\r\n" % (hora))
                arquivo1.close()

            if(ack[0] == 4):
                print('Process state error: packet building')
                hoje = "%s" % (time.strftime("%Y_%m_%d"))
                arquivo1 = open("log_record.%s.log" % (hoje), "a")
                hora = time.strftime("%H:%M:%S %Z")

                arquivo1.write("[%s] Process state error: packet building\r\n" % (hora))
                arquivo1.close()

            if(ack[0] == 8):
                print('Process state error: saving key')
                hoje = "%s" % (time.strftime("%Y_%m_%d"))
                arquivo1 = open("log_record.%s.log" % (hoje), "a")
                hora = time.strftime("%H:%M:%S %Z")

                arquivo1.write("[%s] Process state error: saving key\r\n" % (hora))
                arquivo1.close()

            if(ack[1] == 0):
                print('     Key sucessfully saved')

            if(ack[1] & 0x01):
                print('     Device\'s received packet with wrong start byte')
                hoje = "%s" % (time.strftime("%Y_%m_%d"))
                arquivo1 = open("log_record.%s.log" % (hoje), "a")
                hora = time.strftime("%H:%M:%S %Z")

                arquivo1.write("[%s] Device\'s received packet with wrong start byte\r\n" % (hora))
                arquivo1.close()

            if(ack[1] & 0x02):
                print('     Device\'s received packet with wrong length')
                hoje = "%s" % (time.strftime("%Y_%m_%d"))
                arquivo1 = open("log_record.%s.log" % (hoje), "a")
                hora = time.strftime("%H:%M:%S %Z")

                arquivo1.write("[%s] Device\'s received packet with wrong length\r\n" % (hora))
                arquivo1.close()

            if(ack[1] & 0x04):
                print('     Device\'s received packet with unknown request')
                hoje = "%s" % (time.strftime("%Y_%m_%d"))
                arquivo1 = open("log_record.%s.log" % (hoje), "a")
                hora = time.strftime("%H:%M:%S %Z")

                arquivo1.write("[%s] Device\'s received packet with unknown request\r\n" % (hora))
                arquivo1.close()

            if(ack[1] & 0x08):
                print('     Device\'s received packet with unknown data')
                hoje = "%s" % (time.strftime("%Y_%m_%d"))
                arquivo1 = open("log_record.%s.log" % (hoje), "a")
                hora = time.strftime("%H:%M:%S %Z")

                arquivo1.write("[%s] Device\'s received packet with unknown data\r\n" % (hora))
                arquivo1.close()

            if(ack[1] & 0x10):
                print('     Device\'s received packet with unknown wrong stop byte')
                hoje = "%s" % (time.strftime("%Y_%m_%d"))
                arquivo1 = open("log_record.%s.log" % (hoje), "a")
                hora = time.strftime("%H:%M:%S %Z")

                arquivo1.write("[%s] Device\'s received packet with unknown wrong stop byte\r\n" % (hora))
                arquivo1.close()

        #%%
        key, req = option_name,option_action
        PacketSent = PacketBuilder(START_BYTE,DATA_TYPE[key]['PCT_LEN'][req],REQU_TYPE[req],
                               DATA_TYPE[key]['DATA'],
                               PopulatePayload(req,DATA_TYPE[key]['PLD_LEN']),STOP_BYTE)
        #%%
        ser.open()
        ser.write(PacketSent)
        #PACK = ser.read(PacketSent[1]+1)
        PACK = ser.read(255)
        #%%
        ser.close()
        #%%
        # start = FindByte(PACK[:],START_BYTE)
        # stop  = FindByte(PACK[::-1],STOP_BYTE)
        # temp = PACK[start:len(PACK)-stop]
        temp = ReceivedPacketCleaner(PACK,DATA_TYPE[key]['PCT_LEN'][req])
        PacketReceived = []
        for data in temp:
            PacketReceived.append(data)
        #%%
        print('Packet sent:     '+str(PacketSent))
        print('Response packet: '+str(PacketReceived))
        #%%
        if(PacketReceivedCheck(PacketReceived) == 0):
            payload = PacketPayloadDecode(PacketReceived)
            if(len(payload) == DATA_TYPE['ACK']['PLD_LEN']):
                AcknoledgeDecoder(payload)
                return payload
            else:
                return PacketPayloadDecode(PacketReceived)
        else:
            return PacketReceived
