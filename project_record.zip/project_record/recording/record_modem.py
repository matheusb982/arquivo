import requests
import time
import base64
import serial
import os
import struct
#from recording import run_record
GET_DEV_EUI = 0x75
UPDATE_APP_EUI = 0x73
UPDATE_APP_KEY = 0x74
startbyte = 0x4c
headersize = 6
COM_PORT='/dev/ttyUSB0'

class record(object):
    def run(self):
        #app_eui = [0x70,0xb3,0xd5,0x7e,0xd0,0x00,0x70,0xa9]
        #app_key = [0x78,0xa6,0xfb,0xab,0xf0,0x1d,0x7d,0xf3,0x5d,0x73,0x61,0xce,0x1c,0x28,0x25,0xcc]
        dev_eui = record.GetDevEui()
        dev_str = ''.join(format(x,'02x') for x in dev_eui)

        url = 'http://54.207.55.58:3000/api/v1/modems/show_dev/'+dev_str
        headers = {'X-User-Email':'matheusb982@gmail.com', 'X-User-Token':'-uTbeyph7H1cXserAPYW'}

        r = requests.get(url, headers=headers)

        if (r.status_code == 200):
            js = r.json()

            if js != None:
                print('modem')

                appeui  = js['appeui']
                appkey  = js['appkey']

                record.UpdateAppEui(record.convert_array_hex(appeui))
                record.UpdateAppKey(record.convert_array_hex(appkey))
                print('DevEUI: '+ dev_str)
                print('Appeui: '+ js[0]['appeui'])
                print('AppKey: '+ js[0]['appkey'])

                return [2,'Modem Regravado']


            else:
                url = 'http://54.207.55.58:3000/api/v1/modems.json'
                headers = {'X-User-Email':'matheusb982@gmail.com', 'X-User-Token':'-uTbeyph7H1cXserAPYW'}

                rm = requests.get(url, headers=headers)

                js = rm.json()

                if (rm.status_code == 200):
                    # print('gravando')
                    # print (js[0]['id'])
                    # print (js[0]['appeui'])
                    # print (js[0]['appkey'])
                    # print('terminado params')

                    record.UpdateAppEui(record.convert_array_hex(js[0]['appeui']))
                    record.UpdateAppKey(record.convert_array_hex(js[0]['appkey']))
                    print('DevEUI: '+ dev_str)
                    print('Appeui: '+ js[0]['appeui'])
                    print('AppKey: '+ js[0]['appkey'])
                    #print("AppEui:" + ''.join(format(x,'02x') for x in app_eui))
                    #print("AppKey:" + ''.join(format(x,'02x') for x in app_key))

                    # update api
                    # print('Atualizando API')
                    # dat = {'modem[used]':'true', 'modem[deveui]':dev_str}
                    #
                    # urlp = 'http://54.207.55.58:3000/api/v1/modems/'+str(js[0]['id'])
                    #
                    # rp = requests.put(urlp, headers=headers, data = dat)
                    #
                    # print(rp.text)
                    return [2,'Modem Gravado']

        else:
            return [0, 'Erro ao se comunicar com API']

    def BuildPacket( command, data ):
    	datalen = len(data)
    	pack = []
    	pack.append(startbyte)
    	pack.append( headersize + datalen)
    	pack.append(command)
    	pack.append(datalen)
    	for i in range(0,datalen):
    		pack.append(data[i])

    	pack.append(0)
    	checksum = 0
    	for i in pack:
    		checksum += i

    	pack.append(checksum%256)
    	print(''.join(format(x,'02x') for x in pack))

    	# hexpack = ''.join([chr(item) for item in pack])
    	# dataencoded = base64.b64encode(hexpack)
    	# print(dataencoded)
    	return pack

    def GetDevEui():
            pack = record.BuildPacket(GET_DEV_EUI,[])
            try:
                    ser = serial.Serial(COM_PORT,9600,timeout=10)
                    ser.write(pack)
                    ser.write('\n'.encode())
                    resp = ser.readline()
                    #print(''.join(format(ord(x),'02x') for x in resp))

            except serial.SerialException:
                    print('port already open')

            ser.close()
            return resp[4:12]

    def UpdateAppEui(appEui):
            pack = record.BuildPacket(UPDATE_APP_EUI,appEui)
            try:
                    ser = serial.Serial(COM_PORT,9600,timeout=10)
                    ser.write(pack)
                    ser.write('\n'.encode())
                    resp = ser.readline()
                    #print(''.join(format(ord(x),'02x') for x in resp))

            except serial.SerialException:
                    print('port already open')

            ser.close()

    def UpdateAppKey(appKey):
            #print('Entrou appkey: ')
            #print(appKey)
            pack = record.BuildPacket(UPDATE_APP_KEY,appKey)
            try:
                    ser = serial.Serial(COM_PORT,9600,timeout=10)
                    ser.write(pack)
                    ser.write('\n'.encode())
                    resp = ser.readline()
                    #print(''.join(format(ord(x),'02x') for x in resp))

            except serial.SerialException:
                    print('port already open')

            ser.close()

    def convert_array_hex(value):
        ar = value
        # print(len(ar))
        # print(ar[0:2])
        som = 0
        pac = []
        for letter in ar:
            som = som + 1
            da = ''
            if int(som) % 2 == 0:
                da = '0x'+ar[som-2]+letter
                pac.append(int(da, 16))
        return pac
