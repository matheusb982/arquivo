#!/usr/bin/env python
# coding: utf-8

import base64
import serial
import os
import struct

startbyte = 0x4c
headersize = 6

DLMS_SERVICE = 0x47
FROZEN_SERVICE = 0x58
UPDATE_AK = 0x68
UPDATE_EK = 0x72
UPDATE_APP_EUI = 0x73
UPDATE_APP_KEY = 0x74
GET_DEV_EUI = 0x75
RESET_DEV = 0xFF
COM_PORT='/dev/ttyUSB0'

def BuildPacket( command, data ):
	datalen = len(data)
	pack = []
	pack.append(startbyte)
	pack.append( headersize + datalen)
	pack.append(command)
	pack.append(datalen)
	for i in range(0,datalen):
		pack.append(data[i])

	pack.append(0)
	checksum = 0
	for i in pack:
		checksum += i

	pack.append(checksum%256)
	print ''.join(format(x,'02x') for x in pack)

	hexpack = ''.join([chr(item) for item in pack])
	dataencoded = base64.b64encode(hexpack)
	print(dataencoded)
	return pack


def Get(class_id,obis,attribute_id):
        header = [0xc0,0x01,0xc1]
        data =  header + class_id + obis + attribute_id + [0x00]

        print(data)
        BuildPacket(DLMS_SERVICE,data)

def Action(class_id,obis,attribute_id,data=[]):
        header = [0xc3,0x01,0xc1]
        if len(data) > 0:
                d = header + class_id + obis + attribute_id + [len(data)] + data
        else:
                d = header + class_id + obis + attribute_id



        print(d)
        BuildPacket(DLMS_SERVICE,d )

def Set(class_id,obis,attribute_id,data =[]):
        header = [0xc1,0x01,0xc1]
        if len(data) > 0:
                d = header + class_id + obis + attribute_id + [len(data)] + data
        else:
                d = header + class_id + obis + attribute_id
        print(d)
        BuildPacket(DLMS_SERVICE,d)

def GetFrozen(index):
        data = [index]

        print(data)
        BuildPacket(FROZEN_SERVICE,data)


def UpdateAppEui(appEui):
        pack = BuildPacket(UPDATE_APP_EUI,appEui)
        try:
                ser = serial.Serial(COM_PORT,9600,timeout=10)
                ser.write(pack)
                ser.write('\n')
                resp = ser.readline()
                print ''.join(format(ord(x),'02x') for x in resp)

        except serial.SerialException:
                print 'port already open'

        ser.close()

def UpdateAppKey(appKey):
        pack = BuildPacket(UPDATE_APP_KEY,appKey)
        try:
                ser = serial.Serial(COM_PORT,9600,timeout=10)
                ser.write(pack)
                ser.write('\n')
                resp = ser.readline()
                print ''.join(format(ord(x),'02x') for x in resp)

        except serial.SerialException:
                print 'port already open'

        ser.close()

def UpdateAK(AK):
        BuildPacket(UPDATE_AK,AK)

def UpdateEK(EK):
        BuildPacket(UPDATE_EK,EK)

def GetDevEui():
        pack = BuildPacket(GET_DEV_EUI,[])
        try:
                ser = serial.Serial(COM_PORT,9600,timeout=10)
                ser.write(pack)
                ser.write('\n')
                resp = ser.readline()
                print ''.join(format(ord(x),'02x') for x in resp)

        except serial.SerialException:
                print 'port already open'

        ser.close()
        return resp[4:12]

def ResetDev():
        pack = BuildPacket(RESET_DEV,[])
        try:
                ser = serial.Serial(COM_PORT,9600,timeout=10)
                ser.write(pack)
                ser.write('\n')
                resp = ser.readline()
                print ''.join(format(ord(x),'02x') for x in resp)

        except serial.SerialException:
                print 'port already open'

        ser.close()

def updateTime(year,month,day,hour,minute,second):
	datetime = []
	date = struct.pack(">H",year) + struct.pack(">B",month) + struct.pack(">B",day)
	time = struct.pack(">B",hour) + struct.pack(">B",minute) + struct.pack(">B",second)

	datetime.append(0x09)
	datetime.append(0x0c)
	for i in date:
		datetime.append(ord(i))

	datetime.append(0)

	for i in time:
		datetime.append(ord(i))

	datetime.append(0xff)
	datetime.append(0x80)
	datetime.append(0x00)
	datetime.append(0x00)

	Set([0x00,0x08],[0x00,0x00,0x01,0x00,0x00,0xff],[0x02],datetime)

def factory():
        app_eui = [0x70,0xb3,0xd5,0x7e,0xd0,0x00,0x70,0xa9]
        app_key = [ord(i) for i in os.urandom(16)]
        dev_eui = GetDevEui()
        UpdateAppEui(app_eui)
        UpdateAppKey(app_key)
        print "DevEui:" + ''.join(format(ord(x),'02x') for x in dev_eui)
        print "AppEui:" + ''.join(format(x,'02x') for x in app_eui)
        print "AppKey:" + ''.join(format(x,'02x') for x in app_key)

def main():
	UpdateAK([0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00])
	UpdateEK([0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00])


if __name__ == "__main__":
    factory()
