import tkinter as tk
from tkinter import *
from tkinter import messagebox
from recording import record
from recording import record_modem
from recording import rewrite_record

class Application(tk.Frame):
    def __init__(self, master=None):
        super().__init__(master)
        listbox = Listbox(root)
        self.pack()
        self.create_widgets()

    def create_widgets(self):
        #button inital
        w = Label(self, text="")
        w.pack()
        self.button_etiqueta = tk.Button(self, width=15, height=5)
        self.button_etiqueta["text"] = "Etiqueta"
        self.button_etiqueta["command"] = self.say_etiqueta
        self.button_etiqueta.pack(side="top")

        self.button_modem = tk.Button(self, width=15, height=5)
        self.button_modem["text"] = "Modem"
        self.button_modem["command"] = self.say_modem
        self.button_modem.pack(side="top")

    def say_modem(self):
        r = record_modem.record()
        result = r.run()
        res = result

        if(res[0]==2):
            messagebox.showinfo("Finalizado" , res[1])

    def say_etiqueta(self):
        #print("Iniciando gravação...")
        r = record.record()
        result = r.run()
        res = result

        if(res[0]==0):
            messagebox.showerror("Erro", res[1])
        elif(res[0]==1):
            #messagebox.showwarning("Warning", res[1])
            result = messagebox.askquestion("Delete", res[1]+" - Deseja regravar?", icon='warning')
            if result == 'yes':
                res = rewrite_record.record()
                result = res.run()
                rest = result

                if(rest[0]==2):
                    messagebox.showinfo("Finalizado" , rest[1])
                elif(rest[0]==0):
                    messagebox.showerror("Erro", rest[1])

            else:
                print('finalizado')
        elif(res[0]==2):
            messagebox.showinfo("Finalizado" , res[1])

root = tk.Tk()
root.title("Gravação Etiqueta e Modem")
root.geometry("350x250")
app = Application(master=root)
app.mainloop()
